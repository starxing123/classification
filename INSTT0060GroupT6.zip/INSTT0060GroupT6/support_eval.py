#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Supporting evaluation 
"""
import pandas as pd
import numpy as np
#The following parts are built for confusion matrix, accuracy, recall, precision, and f1 score 
def confusion_matrix_plot(targets,predictions):
    #confusion matrix using pandas 
    cm = pd.crosstab(targets, predictions, rownames=['Actual Quality'], colnames=['Predicted Quality'],margins = True)
    return cm.values

def accuracy(targets, predictions):
    score = targets == predictions
    return np.average(score)

#null_accuray is to examine when all predictions are made based on the majority (eg.all good wine)
#If null accuray is bigger than accuracy then our model is worse than just predicting based on the majority
def null_accuracy(targets,predictions):
    score_1 = targets == 1
    score_0 = targets == 0
    if score_1.sum() > score_0.sum():
        return np.average(score_1)
    else:
        return np.average(score_0)

def precision_recall_fscore(targets, predictions):
    """Compute precision, recall, F-measure and support for each class
    The precision is the ratio ``tp / (tp + fp)`` where ``tp`` is the number of
    true positives and ``fp`` the number of false positives. The precision is
    intuitively the ability of the classifier not to label as positive a sample
    that is negative.
    The recall is the ratio ``tp / (tp + fn)`` where ``tp`` is the number of
    true positives and ``fn`` the number of false negatives. The recall is
    intuitively the ability of the classifier to find all the positive samples.
    The F-beta score can be interpreted as a weighted harmonic mean of
    the precision and recall, where an F-beta score reaches its best
    value at 1 and worst score at 0.
    ----------
    Returns
    -------
    precision : float 
    recall : float 
    f_score : 
    support/(true_sum) : int 
            optional, describing how many real good wine
            i just include it since it was in the original sklearn library, 
    References
    ----------
    .. [1] `Wikipedia entry for the Precision and recall
           <https://en.wikipedia.org/wiki/Precision_and_recall>`_
    .. [2] `Wikipedia entry for the F1-score
           <https://en.wikipedia.org/wiki/F1_score>`_
    .. [3] `Discriminative Methods for Multi-labeled Classification Advances
           in Knowledge Discovery and Data Mining (2004), pp. 22-30 by Shantanu
           Godbole, Sunita Sarawagi
           <http://www.godbole.net/shantanu/pubs/multilabelsvm-pakdd04.pdf>`_
    """

    # Calculate tp_sum, pred_sum, true_sum ###
    MCM = confusion_matrix_plot(targets, predictions)
    tp_sum = MCM[1, 1]
    pred_sum = tp_sum + MCM[0, 1]
    true_sum = tp_sum + MCM[1, 0]

    precision = tp_sum/pred_sum
    recall = tp_sum/true_sum
    f_score = 2* precision * recall / (precision + recall)

    return precision, recall, f_score, true_sum