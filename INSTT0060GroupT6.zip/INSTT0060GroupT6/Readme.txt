Model selection file:1.1 Wine Quality Selection applying Fisher’s Linear Discriminant:
File: wine_fisher.pyCommand line:		python wine_fisher.py winequality-red.csv

* Please note that the heat maps we present in the report are those of matrices with 2500 elements, these heat maps took a long time to generate and so for the purposes of convenience when the submitted .py files are they generate only heat maps for matrices of 25 elements, the user may alter this if they wish.1.2 Wine Quality Selection applying Logistic Regression:
File: wine_logistic_regression.py Command line:		python wine_logistic_regression.py winequality-red.csv1.3 Wine Quality Selection applying Random Forest:
File: wine_random_forest.pyCommand line:		python wine_random_forest.py winequality-red.csv

*Please note that the model selection took several minutes to run2.1 Abalone selection applying Fisher’s Linear Discriminant
File: abalone_fisher.pyCommand line:		python abalone_fisher.py abalone.csv

* Please note that the heat maps we present in the report are those of matrices with 2500 elements, these heat maps took a long time to generate and so for the purposes of convenience when the submitted .py files are they generate only heat maps for matrices of 25 elements, the user may alter this if they wish. 2.2 Abalone selection applying Logistic Regression:
File:abalone_logistic_regression.pyCommand line:		python abalone_logistic_regression.py abalone.csv	2.3 Abalone selection applying Random Forest:
File: abalone_random_forest.pyCommand line:		python abalone_random_forest.py abalone.csv*Please note that the model selection took several minutes to runSupporting codes:	Fomlads: provided for this coursework	T3: tutorial codes from Tutorial 3	Support_eval.py: supporting accuracy, recall, precision and f1 score 


Jupyter notebook: 

Development process with detailed comments for abalone classification
	abaloneclassification.ipynb

Development process with detailed comments for wine classification
	WinesClassifications.ipynb


