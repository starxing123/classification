"""
INST0060 Group project
Fisher Linear Discriminant model selection on abalone dataset 

"""

import pandas as pd
import numpy as np
import csv
import sys
import matplotlib.pyplot as plt
from fomlads.model.classification import fisher_linear_discriminant_projection
from fomlads.model.classification import project_data
from fomlads.evaluate.eval_classification import misclassification_error
from fomlads.plot.exploratory import plot_class_histograms
from fomlads.plot.exploratory import plot_scatter_array_classes
from fomlads.plot.evaluations import plot_roc

#for crross validation (retrieved from Tutorial 3)
from t3.regression_train_test import create_cv_folds
from t3.regression_train_test import train_and_test_partition
#for applying RBF 
from t3.regression_models import construct_rbf_feature_mapping

    
def main(ifname=sys.argv[1]):
    N, Dim, standardised_data, targets, header = import_data_and_standardize(ifname)
    model_selection_fisher_no_basis(N, standardised_data, targets,header)
    model_selection_fisher_rbf(N,standardised_data,targets)
    
def import_data_and_standardize(ifname = sys.argv[1]):
    #Output parameters:
    #N : the number of data points
    #Dim : the number of attribute of the data
    #standardised_data: standarrdised data matrix 
    #targets: #reated a 1D vector where 0 = bad wine, 1 = good wine
    #header: data headers
    data = pd.read_csv(ifname)
    for i in range(len(data)):
        inti = int(data.iloc[i,8])
        if inti>10:
            data.iloc[i,8] = 1
        else:
            data.iloc[i,8] = 0
            #one hot vecotor for 'sex' category 
    data_dummies = pd.get_dummies(data)
    data_Rings = data.Rings
    data_dummies = data_dummies.drop('Rings',axis=1)
    data_dummies.insert(10,'Rings',data_Rings)
    data = data_dummies
    header = data[1:1]
    data_as_array = np.array(data)

    
    targets = data_as_array[:,-1]
    data_matrix = data_as_array[:, 0:-1] #data_matrix is a 2D array which can be used to represent all the datapoints where is row is a datapoint
    N = data_matrix.shape[0] 
    Dim = data_matrix.shape[1]
    #standardising data below
    standardised_data = np.zeros([N , Dim])
    for i in range(Dim): 
        column_i = data_matrix[:,i]
        column_i_mean = np.mean(column_i)
        colum_i_std = np.std(column_i)
        standardised_data[:,i] = (column_i - column_i_mean) / colum_i_std
    print('the number of Rings greater than 10 is {} \n \n'.format(np.sum(targets)))
    return N, Dim, standardised_data, targets, header


def fischerpredicts(w0, projected_inputs):
    
    #This function takes a value of w0 and applies it to projected inputs.
    #w0 is the "threshold" or "cutoff" used to predict class membership
    #projected_inputs is what you get when multiplying the weights (found by fishers) by the inputs, it is 1D
    #predicts is a vecor where each  number is 1 or 0
    N = projected_inputs.shape[0]
    predicts = np.zeros([N])
    for i in range(N):
        if (projected_inputs[i] > w0).any():
            predicts[i] = 1
    return predicts


def construct_roc_data(N, standardised_data, projected_data, targets):
    new_ordering = np.argsort(projected_data)
    sorted_projections = projected_data[new_ordering]
    sorted_targets = targets[new_ordering]
    num_neg = np.sum(1-targets)
    num_pos = np.sum(targets)
    roc_data = np.empty([N, 5])
    #roc_data is a 2D array with 5 colums. The array is alled roc_data
    #Column 1 is numbers in ascending order (ie 1, 2, 3, 4, 5 etc)
    #Column 2 is a value of w0
    #Column 3 is the false positive rate (FPR) for a given value of w0
    #Column 4 is the true positive rate (TPR) for a given value of 
    #Column 5 gives the value of TPR - FPR
    
    for i, w0 in enumerate(sorted_projections):
            roc_data[i,0] = i
            roc_data[i,1] = sorted_projections[i]
            roc_data[i,2] = np.sum(1-sorted_targets[i:])/num_neg
            FPR = roc_data[i,2]
            roc_data[i,3] = np.sum(sorted_targets[i:])/num_pos
            TPR = roc_data[i,3]
            roc_data[i,4] = TPR - FPR

    highest_value_indicies = np.argmax(roc_data, axis=0) #In these two lines we fine the value w0 which gives the highest number for TPR - FPR
    w0 = roc_data[highest_value_indicies[4], 1]
    return roc_data,w0


def cross_val_fishers(w0, inputs, targets, folds):
    #this function performs a cross validation on the fischers model we hav created above
    #w0 = the threshold value we found to be the besdt cutoff to identify class memebership from the projected data vector
    #inputs = our data points in the form of a matrix
    #targets = the actual class membership of each data oint in 1s and 0s
    #folds = this is an array containing tuples, the tuples contain a pair of boolean arrays. this is creasted from the
    #create cv_folds() function in tutorial 3 (regression_train_test.py)
    
    N = inputs.shape[0] #Number of data points
    num_folds = len(folds) #finds the number of folds
    train_errors = np.empty(num_folds)
    test_errors = np.empty(num_folds)
    
    for f,fold in enumerate(folds):
        train_part, test_part = fold
        train_inputs, train_targets, test_inputs, test_targets = train_and_test_partition(inputs, targets, train_part, test_part)
        weights = fisher_linear_discriminant_projection(train_inputs, train_targets)
        
        train_projected_data = project_data(train_inputs, weights)
        train_predicts = fischerpredicts(w0, train_projected_data)
        
        test_projected_data = project_data(test_inputs, weights)
        test_predicts = fischerpredicts(w0, test_projected_data)
        
        train_error = misclassification_error(train_targets, train_predicts)
        test_error = misclassification_error(test_targets, test_predicts)

        train_errors[f] = train_error
        test_errors[f] = test_error
        
    #the first returned array retruned is the the training errors. It a X number of values where X is the number of folds
    #used to perform the cross validation, each number in the array represents the misclassification error of the training data
    #within that particular "experiment"
    
    #the second returned array is the test errors, it is the same as the first array but the error was calculated on the held out 
    #test data
    return train_errors, test_errors

def model_selection_fisher_no_basis(N,standardised_data,targets,header):
    
    weights = fisher_linear_discriminant_projection(standardised_data, targets)
    projected_data = project_data(standardised_data, weights)
    print("\n plotting histogram of the projected data to see how linearly seperable it is \n")
    plot_class_histograms(projected_data, targets) # plots a histogram to show how linearly seperable the data is
    #construct and plot roc curve 
    roc_data,w0 = construct_roc_data(N, standardised_data, projected_data, targets)
    print("\n plotting the roc curve for the Fisher's Linear Discriminant with no basis functions \n")
    fig,ax = plot_roc(roc_data[:,2], roc_data[:,3],colour='g')
    ax.legend(['fisher'])
    predictions = fischerpredicts(weights,projected_data) #Returns the predictions from or trained model weights
    print("\n  ***Fisher Discriminant with no basis function***  \n")
    print("\n the confusion matrix for the above model is shown below \n")	
    print(pd.crosstab(targets, predictions, rownames=['Actual Quality'], colnames=['Predicted Quality'],margins = True))
    plt.show()
    #apply cross-validation 
    num_folds = 3 
    folds = create_cv_folds(N, num_folds) 
    train_error, test_error = cross_val_fishers(w0, standardised_data, targets, folds)
    print(" \n \ntrain_error_cv: if these are close it implies the model is stable", train_error)
    print("test_error_cv: if these are close it implies the model is stable",test_error)
    print (" \n *The mean test error for fishers linear discriminant is", np.mean(test_error))
    
def model_selection_fisher_rbf(N,standardised_data,targets):
#We will use Radil Basis Functions as our basis functions
#This will require the process of model selection


#RBFs are defined by two parameters, 1) the number of centers
#2) the scale of the basis functions
    print(" \n \n ***Fisher's Discriminant with RBF as basis functions*** \n")
    scales = np.linspace(0.1,9, 5) #For the purposes of convenience/timesaving we have only selected 5 scales to explore, in our abaloneclassification.ipynb notebook we explore 50
    array_of_numbers_of_centres = np.around(np.linspace(1,40, 5)).astype(int) #For the purposes of convenience/timesaving we have only selected 5 number of centres to explore, in our abaloneclassification.ipynb notebook we explore 50
    heat_map = np.zeros([scales.size, array_of_numbers_of_centres.size]) 
	#heat map is a matrix which will show the different error for each configuration of our parameters of scale and number of centers. 
	#each element of the heat map will be a different error value representing the test error obtained from cross validation for a different pair of numberofcentres/scale
    #each row in the heat map is representing the scale
    #each column in the heat mep is representing the number of centers
    parameter_list = [] #this is a list of the parameters which has indicies which correspond to the heatmap, an example of this:
    #if np.argmin(heat_map) yields the number 17 then parameter_list[17] will contain a list [scale, centres] which gives the lowest
    #error in the heat_map

    for i, scale in enumerate(scales):
        for j, number_of_centres in enumerate(array_of_numbers_of_centres):
            
        
            indexes = np.random.choice(N,number_of_centres) #here is one of the biggest flaws in our model selection
            #we are selecting our centres RANDOMLY, according to the literature np.random.choice selects values randomly according to
            #a unifrom distribution
            centres = standardised_data[indexes,:]             
            feature_mapping = construct_rbf_feature_mapping(centres,scale)
            designmtx = feature_mapping(standardised_data)
            parameter_list.append([scale, centres])
        
            try:
                weights_ms = fisher_linear_discriminant_projection(designmtx, targets) 
                #the "_ms" after "weights" stands for 
                #model selection to help distinguish it from the "weights" variable above.
                projected_data_ms = project_data(designmtx, weights_ms)
                new_ordering_ms = np.argsort(projected_data_ms)
                sorted_projections_ms = projected_data_ms[new_ordering_ms]
                sorted_targets = targets[new_ordering_ms]
                num_neg = np.sum(1-targets)
                num_pos = np.sum(targets)
        
                find_optimal_w0 = np.empty([N, 2])
                for idx, w0 in enumerate(sorted_projections_ms):
                    find_optimal_w0[idx,0] = sorted_projections_ms[idx]
                    FPR = np.sum(1-sorted_targets[idx:])/num_neg
                    TPR = np.sum(sorted_targets[idx:])/num_pos
                    find_optimal_w0[idx,1] = TPR - FPR
                num_folds = 3 
                folds = create_cv_folds(N, num_folds) 
                indexes_to_find_best_w0 = np.argmax(find_optimal_w0, axis=0)
                w0_ms = find_optimal_w0[indexes_to_find_best_w0[1], 0]
                train_errors, test_errors = cross_val_fishers(w0_ms, designmtx, targets, folds)
            
            except np.linalg.LinAlgError:
                print('A singular matrix was encountered when the scale was {} and the number of centres was {}'.format(scale, number_of_centres))
                test_errors = 1.01
                
            heat_map[i, j] = np.mean(test_errors)
            print("finished element {}/{} of the heat_map for model selection".format(j + i*(len(array_of_numbers_of_centres)),heat_map.size - 1))
    
    
    
    plt.imshow(heat_map, cmap='hot', interpolation='nearest')#this line gives a representation of the heat_map. the darker squares represent areas of the lowest error
    plt.plot()  
	
    best_parameters = parameter_list[np.argmin(heat_map)] #This is a list which gives the parameters used to get the model which gives the lowest_error
    best_scale = best_parameters[0]
    best_centres = best_parameters[1]
    lowest_error = np.amin(heat_map)
	
    print("\n *the misclassification error when using the best hyperparameters for the RBFs is {} \n".format(lowest_error))

#first lets create our designmatrix using our best parameters
    feature_mapping = construct_rbf_feature_mapping(best_centres,best_scale)
    designmtx_RBF = feature_mapping(standardised_data) #our design matrix made using the best parameters

    weights = fisher_linear_discriminant_projection(designmtx_RBF, targets) #our weights now calculated using the designmtx_RBF
    projected_data_rbf = project_data(designmtx_RBF, weights)
    print("\n plotting the histogram of the projected data of Fishers with RBF to show how linearly seperable it is \n")
    plot_class_histograms(projected_data_rbf, targets)#here we plott he histogram this time with our design matrix model to see how linearly seperable our data is
    
    plt.show()
    #construct and compare plot roc curve 
    roc_data_rbf,w0 = construct_roc_data(N, designmtx_RBF, projected_data_rbf, targets)
    #confusion matrix for fisher applied RBF 
    predictions = fischerpredicts(w0,projected_data_rbf)
    print("\n the confusion matrix with this model is shown below \n")
    print(pd.crosstab(targets, predictions, rownames=['Actual Quality'], colnames=['Predicted Quality'],margins = True))
    
    #plot a roc curve for fisher_rbf 
    fig1,ax1 = plot_roc(roc_data_rbf[:,2], roc_data_rbf[:,3])
    #plot a comparison roc curve against fisher without rbf 
    fig,ax = plot_roc(roc_data_rbf[:,2], roc_data_rbf[:,3],colour='b')
    ax.legend(['Fisher_RBF'])
    print("\n Fisher Discriminant without RBF applied ROC Curve")
    #plot a comparison roc curve against fisher without rbf 
    weights = fisher_linear_discriminant_projection(standardised_data, targets)
    projected_data = project_data(standardised_data, weights)
    roc_data,w0 = construct_roc_data(N,standardised_data, projected_data,targets)
    print("Fisher Discriminant with/without RBF applied ROC Curve")
    plot_roc(roc_data[:,2], roc_data[:,3],fig_ax = (fig,ax),colour ='g')
    plt.show()
    



if __name__ == '__main__':
    if len(sys.argv) == 1:
        print('ERROR: Please provide filename/path in command line')
        main() # calls the main function with no arguments
    elif len(sys.argv) == 2:
        # read the first argument as the input filename/path
            main(ifname=sys.argv[1])









