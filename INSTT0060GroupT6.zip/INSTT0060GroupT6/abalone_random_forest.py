#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
INST0060 Group project
Random forest model selection on abalone dataset 

"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys
from fomlads.evaluate.eval_classification import misclassification_error
from fomlads.evaluate.partition import train_and_test_partition
from fomlads.evaluate.partition import train_and_test_filter
from sklearn.ensemble import RandomForestClassifier
from support_eval import accuracy

def main(
        ifname, input_cols=None, target_col=None, classes=None):
    #import data from function import_for_classification
    inputs, targets, field_names, classes = import_for_classification(
        ifname, input_cols=input_cols, target_col=target_col, classes=classes)
    N = inputs.shape[0]
    train_filter, test_filter = train_and_test_filter(N, test_fraction=0.25)
    train_inputs, train_targets, test_inputs, test_targets = train_and_test_partition(
            inputs, targets, train_filter, test_filter)
    #model selection
    best_estimator,best_max_depth,best_min_samples_split = RF_model_selection(
            train_inputs,train_targets,test_inputs,test_targets)
     #best model using the parameters selected in model selection
    test_predict,predict_proba, model = RF_model(
            train_inputs,train_targets,test_inputs,best_estimator,best_max_depth,best_min_samples_split)
    predictions = model.predict(inputs)
    roc_curve(test_targets,test_predict)
    
    print(pd.crosstab(targets, predictions, rownames=\
                ['Actual Quality'], colnames=['Predicted Quality'],margins = True))
    print("Accuracy:", accuracy(test_targets,test_predict))
    #print("Precision, Recall, F1 Score ","\n", precision_recall_fscore(targets,predictions))
    print ("Misclassification error", misclassification_error(test_targets,test_predict))
    
#Construct random forest model 
def RF_model(x_train,y_train,x_test,n_estimators,max_depth,min_samples_split)  :
    model = RandomForestClassifier(
            n_estimators = n_estimators,\
            criterion = "gini",max_depth=max_depth,\
            )
    #n_estimators: model selection
    #max_depth: controlled to prevent overfitting 
    #criterion: use default of gini 
    #max_features: None- Selecting all features 
    #min_samples_split - variable controlled
    #min_samples_leaf - not a huge datatset, leave as default
    #min_weight_fraction_leaf - not a huge dataset, so no introduction of weight control 
    #max_leaf_nodes - prevent overfitting 
    model.fit(x_train,y_train)
    test_predict = model.predict(x_test)
    predict_proba = model.predict_proba(x_test)
    return test_predict,predict_proba, model

#Randome tree model selection 
def RF_model_selection(x_train,y_train,x_test,y_test):
    model_select_para = []
    accuracy_list = []
    n_estimators = [5,10,15,20,40,60,80,100,150,200]
    
    #model selection on number of trees
    for estimator in n_estimators:
        #print("Number of", estimator,"trees")
        #training
        rf = RandomForestClassifier(n_estimators= estimator, n_jobs=-1)
        rf.fit(x_train,y_train)
        #predicting
        y_pred = rf.predict(x_test)
        
        model_select_para = model_select_para + [[estimator,None,2]]
        accuracy_list = accuracy_list + [accuracy(y_test,y_pred)]
        #print("Accuracy :", accuracy(y_test,y_pred))
        #model selection on max of depth
        max_depths = np.linspace(1, 32, 32,endpoint =True)
        for max_depth in max_depths:
            rf = RandomForestClassifier(
            max_depth = max_depth,n_estimators = estimator)
            rf.fit(x_train,y_train)
            y_pred = rf.predict(x_test)
            model_select_para = model_select_para + [[estimator,max_depth,2]]
            accuracy_list = accuracy_list + [accuracy(y_test,y_pred)]
            #print("Accuracy :", accuracy(y_test,y_pred))
            
            #model selectiton on min_samples_splits
            min_samples_splits = np.linspace(0.1, 1.0, 10, endpoint=True)
            for min_samples_split in min_samples_splits:
                rf = RandomForestClassifier(
                min_samples_split = min_samples_split,\
                max_depth = max_depth,n_estimators = estimator)
                rf.fit(x_train,y_train)
                y_pred = rf.predict(x_test)
                model_select_para = model_select_para + [[estimator,max_depth,min_samples_split]]
                accuracy_list = accuracy_list + [accuracy(y_test,y_pred)]
                #print("Accuracy :", accuracy(y_test,y_pred))
    #finding the highest accuracy 
    accuracy_array = np.asarray(accuracy_list)
    best_acc = np.argmax(accuracy_array)
    print(best_acc)
    #through the highest accuracy, finding relevant combination of hyperparameters
    best_para = model_select_para[best_acc]
    print(best_para)
    best_estimator = best_para[0]
    best_max_depth = best_para[1]
    best_min_samples_split = best_para[2]
    print("best parameters of n_estimators,max_depth,min_samples_splits",model_select_para[best_acc])
    print("Best accuracy: ", accuracy_list[best_acc])
    return best_estimator,best_max_depth,best_min_samples_split

#prepare roc curve data plot
def plot_roc(
        false_positive_rates, true_positive_rates, linewidth=1, fig_ax=None,
        colour=None, ofname=None):
    false_positive_rates = np.append(false_positive_rates,1)
    true_positive_rates = np.append(true_positive_rates,1)
    if fig_ax is None:
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
    else:
        fig, ax = fig_ax
    if colour is None:
        colour='r'
    ax.plot(
        false_positive_rates, true_positive_rates, '-', linewidth=linewidth,
        color=colour)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_aspect('equal', 'box')
    ax.set_xlim([-0.01,1.05])
    ax.set_ylim([-0.01,1.05])
    if not ofname is None:
        print("Saving ROC curve as: %s" % ofname)
        fig.savefig(ofname)
    return fig, ax

#construct and plot roc 
def roc_curve(targets,prediction_probs,fig_ax=None, colour=None):
    thresholds = np.linspace(1,0,101)
    num_neg = np.sum(1-targets)
    num_pos = np.sum(targets)
    false_positive_rates = np.empty(thresholds.size)
    true_positive_rates = np.empty(thresholds.size)
    
    for i, threshold in enumerate(thresholds):
        predicts = (prediction_probs > threshold).astype(int)
        num_false_positives = np.sum((predicts == 1) & (targets == 0))
        num_true_positives = np.sum((predicts == 1) & (targets == 1))
        
        false_positive_rates[i] = np.sum(num_false_positives)/num_neg
        true_positive_rates[i] = np.sum(num_true_positives)/num_pos
    fig, ax = plot_roc(
        false_positive_rates, true_positive_rates, fig_ax=fig_ax, colour=colour)
    plt.show()

    
#data import 
def import_for_classification(
        ifname, input_cols=None, target_col=None, classes=None):
    """
    Imports the iris data-set and generates exploratory plots

    parameters
    ----------
    ifname -- filename/path of data file.
    input_cols -- list of column names for the input data
    target_col -- column name of the target data
    classes -- list of the classes to plot
    returns
    -------
    inputs -- the data as a numpy.array object  
    targets -- the targets as a 1d numpy array of class ids
    input_cols -- ordered list of input column names
    classes -- ordered list of classes
    """
    # if no file name is provided then use synthetic data
    dataframe = pd.read_csv(ifname,sep=',',quotechar='"')
    #print("dataframe.columns = %r" % (dataframe.columns,) )
    #one hot vector encoding 
    for i in range(len(dataframe)):
        inti = int(dataframe.iloc[i,8])
        if inti>10:
            dataframe.iloc[i,8] = 1
        else:
            dataframe.iloc[i,8] = 0
            #one hot vecotor for 'sex' category 
    data_dummies = pd.get_dummies(dataframe)
    data_Rings = dataframe.Rings
    data_dummies = data_dummies.drop('Rings',axis=1)
    data_dummies.insert(10,'Rings',data_Rings)
    dataframe = data_dummies
    
    N = dataframe.shape[0]
        # if no target name is supplied we assume it is the last colunmn in the 
    # data file
    if target_col is None:
        target_col = dataframe.columns[-1]
        potential_inputs = dataframe.columns[:-1]
    else:
        potential_inputs = list(dataframe.columns)
        # target data should not be part of the inputs
        potential_inputs.remove(target_col)
    # if no input names are supplied then use them all
    if input_cols is None:
        input_cols = potential_inputs
    #print("input_cols = %r" % (input_cols,))
    # if no classes are specified use all in the dataset
    if classes is None:
        # get the class values as a pandas Series object
        class_values = dataframe[target_col]
        classes = class_values.unique()
    else:
        # construct a 1d array of the rows to keep
        to_keep = np.zeros(N,dtype=bool)
        for class_name in classes:
            to_keep |= (dataframe[target_col] == class_name)
        # now keep only these rows
        dataframe = dataframe[to_keep]
        # there are a different number of dat items now
        N = dataframe.shape[0]
        # get the class values as a pandas Series object
        class_values = dataframe[target_col]
   # print("classes = %r" % (classes,))
    # We now want to translate classes to targets, but this depends on our 
    # encoding. For now we will perform a simple encoding from class to integer.
    targets = np.empty(N)
    for class_id, class_name in enumerate(classes):
        is_class = (class_values == class_name)
        targets[is_class] = class_id
   # print("targets = %r" % (targets,))

    inputs = dataframe[input_cols].values
    return inputs, targets, input_cols, classes

if __name__ == '__main__':
    if len(sys.argv) == 1:
        print('ERROR: Please provide filename/path in command line')
        main() # calls the main function with no arguments
    elif len(sys.argv) == 2:
        # read the first argument as the input filename/path
            main(ifname=sys.argv[1])