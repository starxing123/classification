#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
INST0060 Group project
Logistic Regression model selection on abalone dataset 
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys

#Now we will try logistic regression to see if that gives
#A better performance, this will be done without basis functions, using basis functions doesnt work well
#As it causes convergence to take very long
from fomlads.plot.evaluations import plot_roc
from fomlads.evaluate.eval_classification import misclassification_error
from fomlads.model.classification import logistic_regression_prediction_probs
from fomlads.model.classification import logistic_regression_predict
from fomlads.evaluate.eval_classification import cross_entropy_error
from fomlads.evaluate.partition import train_and_test_partition
from t3.regression_train_test import create_cv_folds

def main(ifname=sys.argv[1]):

    print("\n ***LOGISTIC REGRESSION*** \n")
    
    #get common used parameters from import_data_and_standardize 
    N, Dim, standardised_data, targets, header = import_data_and_standardize(ifname)
    #in this cell we obtain our weights used to create our logistic regression model
    
    fig,ax = fit_and_plot_roc_logistic_regression(standardised_data, targets)
    
    plt.plot()
    #apply cross-validation 
    num_folds = 3 
    folds = create_cv_folds(N, num_folds) 
    train_errors, test_errors, train_XE, test_XE = cross_val_logistic(standardised_data, targets, folds)
    print("\ntrain errors: ", train_errors, "test errors: ", test_errors," \ntrain Cross Entropy errors ", \
              train_XE, "test Cross Entropy Errors: ", test_XE)
    print('\n **Mean test error', np.mean(test_errors))
    plt.show()
    
def import_data_and_standardize(ifname = sys.argv[1]):
    #Output parameters:
    #N : the number of data points
    #Dim : the number of attribute of the data
    #standardised_data: standarrdised data matrix 
    #targets: #reated a 1D vector where 0 = bad wine, 1 = good wine
    #header: data headers
    data = pd.read_csv(ifname)
    for i in range(len(data)):
        inti = int(data.iloc[i,8])
        if inti>10:
            data.iloc[i,8] = 1
        else:
            data.iloc[i,8] = 0
            #one hot vecotor for 'sex' category 
    data_dummies = pd.get_dummies(data)
    data_Rings = data.Rings
    data_dummies = data_dummies.drop('Rings',axis=1)
    data_dummies.insert(10,'Rings',data_Rings)
    data = data_dummies
    header = data[1:1]
    data_as_array = np.array(data)

    
    targets = data_as_array[:,-1]
    data_matrix = data_as_array[:, 0:-1] #data_matrix is a 2D array which can be used to represent all the datapoints where is row is a datapoint
    N = data_matrix.shape[0] 
    Dim = data_matrix.shape[1]
    #standardising data below
    standardised_data = np.zeros([N , Dim])
    for i in range(Dim): 
        column_i = data_matrix[:,i]
        column_i_mean = np.mean(column_i)
        colum_i_std = np.std(column_i)
        standardised_data[:,i] = (column_i - column_i_mean) / colum_i_std
    #This tells us how mahy good wines we have
    print('the number of Rings greater than 10 is {}'.format(np.sum(targets)))
    return N, Dim, standardised_data, targets, header
    
def logistic_regression_fit_robustINV(
        inputs, targets, weights0=None, threshold=1e-8, lambd = 0.01):
	#Prevents singular matrix errors
   
    # reshape the matrix for 1d inputs
    if len(inputs.shape) == 1:
        inputs = inputs.reshape((inputs.size,1))
    N, D = inputs.shape
    inputs = np.matrix(inputs)
    targets = np.matrix(targets.reshape((N,1)))
    # initialise the weights
    if weights0 is None:
        weights = np.matrix(
            np.random.multivariate_normal(np.zeros(D), 0.0001*np.identity(D)))
    else:
        weights = np.matrix(weights0)
    weights = weights.reshape((D,1))
    # initially the update magnitude is set as larger than the threshold
    update_magnitude = 2*threshold
    while update_magnitude > threshold:
        # calculate the current prediction vector for weights
        predicts = logistic_regression_prediction_probs(inputs, weights)
        # the diagonal reweighting matrix (easier with predicts as flat array)
        R = np.matrix(np.diag(predicts*(1-predicts)))
        # reshape predicts to be same form as targets
        predicts = np.matrix(predicts).reshape((N,1))
        
        HessianMTX = inputs.T*R*inputs
        HessianDIM = HessianMTX.shape[0]
        
        
        lambdI = lambd*np.identity(HessianDIM) 
        robustHessian = HessianMTX + lambdI #Makes the hessian matrix non singular by adding a small diagonal lambda
                
        #print("Before inverse")
        # Calculate the Hessian inverse
        H_inv = np.linalg.inv(robustHessian)
        # update the weights
        new_weights = weights - H_inv*inputs.T*np.matrix(predicts-targets)
        
        update_magnitude = np.sqrt(np.sum(np.array(new_weights-weights)**2))
        # update the weights
        weights = new_weights
    return weights

def fit_and_plot_roc_logistic_regression(
        inputs, targets, fig_ax=None, colour=None):
    """
    Takes input and target data for classification and fits shared covariance
    model. Then plots the ROC corresponding to the fit model.

    parameters
    ----------
    inputs - a 2d input matrix (array-like), each row is a data-point
    targets - 1d target vector (array-like) -- can be at most 2 classes ids
        0 and 1
    """
    weights = logistic_regression_fit_robustINV(inputs, targets)
    #
    thresholds = np.linspace(0,1,101)
    num_neg = np.sum(1-targets)
    num_pos = np.sum(targets)
    
    false_positive_rates = np.empty(thresholds.size)
    true_positive_rates = np.empty(thresholds.size)
    for i, threshold in enumerate(thresholds):
        prediction_probs = logistic_regression_prediction_probs(inputs, weights)
        predicts = (prediction_probs > threshold).astype(int)
        num_false_positives = np.sum((predicts == 1) & (targets == 0))
        num_true_positives = np.sum((predicts == 1) & (targets == 1))
        false_positive_rates[i] = np.sum(num_false_positives)/num_neg
        true_positive_rates[i] = np.sum(num_true_positives)/num_pos
    fig, ax = plot_roc(
        false_positive_rates, true_positive_rates, fig_ax=fig_ax, colour=colour)
    # and for the class prior we learnt from the model
    predicts = logistic_regression_predict(inputs, weights)
    fpr = np.sum((predicts == 1) & (targets == 0))/num_neg
    tpr = np.sum((predicts == 1) & (targets == 1))/num_pos
    ax.plot([fpr], [tpr], 'rx', markersize=8, markeredgewidth=2)
    return fig, ax

#In this cell we define the cross validation function for logistic regression

def cross_val_logistic(inputs, targets, folds):
    num_folds = len(folds) #finds the number of folds
    train_miscl_errors = np.empty(num_folds)
    test_miscl_errors = np.empty(num_folds)
    train_XE_errors = np.empty(num_folds)
    test_XE_errors = np.empty(num_folds)
    for f,fold in enumerate(folds):
        train_part, test_part = fold
        train_inputs, train_targets, test_inputs, test_targets = train_and_test_partition(inputs, targets, train_part, test_part)
        
        weights = logistic_regression_fit_robustINV(train_inputs, train_targets)
        
        train_predicts = logistic_regression_predict(train_inputs, weights)
        test_predicts = logistic_regression_predict(test_inputs, weights)
        
        train_probabilities = logistic_regression_prediction_probs(train_inputs, weights)
        test_probabilities = logistic_regression_prediction_probs(test_inputs, weights)
        
        train_miscl_error = misclassification_error(train_targets, train_predicts)
        test_miscl_error = misclassification_error(test_targets, test_predicts)
        
		
        train_XE_error = cross_entropy_error(train_targets, train_probabilities)
        test_XE_error = cross_entropy_error(test_targets, test_probabilities)
        # we also find the cross entropy error as this is a probailistic model, unfortunately as we are compaing it to fishers, this isnt all that useful
        train_miscl_errors[f] = train_miscl_error
        test_miscl_errors[f] = test_miscl_error
        
        train_XE_errors[f] = train_XE_error
        test_XE_errors[f] = test_XE_error
        
    return train_miscl_errors, test_miscl_errors, train_XE_errors, test_XE_errors

if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        print('ERROR: Please provide filename/path in command line')
        main() # calls the main function with no arguments
    elif len(sys.argv) == 2:
        # read the first argument as the input filename/path
            main(ifname=sys.argv[1])
